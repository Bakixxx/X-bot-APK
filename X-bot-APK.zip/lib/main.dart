
import 'package:flutter/material.dart';

void main() => runApp(XBotApp());

class XBotApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'X Bot',
      theme: ThemeData(
        primaryColor: Colors.black,
        scaffoldBackgroundColor: Colors.yellow,
      ),
      home: Scaffold(
        body: Center(
          child: Text(
            'X',
            style: TextStyle(fontSize: 100, color: Colors.black, fontWeight: FontWeight.bold),
          ),
        ),
      ),
    );
  }
}
