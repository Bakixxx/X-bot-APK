# X Bot – Kripto Al-Sat Mobil Botu
**X Bot**, Binance USDT paritelerinde işlem açabilen bir mobil kripto al-sat botudur. Flutter ile geliştirilmiş olup Codemagic üzerinden kolayca APK'ya dönüştürülebilir.
